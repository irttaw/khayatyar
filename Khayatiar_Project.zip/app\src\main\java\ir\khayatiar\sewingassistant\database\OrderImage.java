package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "order_images")
public class OrderImage {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int orderId;
    public String imagePath;
}
