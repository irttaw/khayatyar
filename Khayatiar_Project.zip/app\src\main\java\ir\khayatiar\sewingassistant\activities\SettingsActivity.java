package ir.khayatiar.sewingassistant.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.utils.PrefManager;

public class SettingsActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private PrefManager prefManager;
    private ImageView imgThemeToggle;
    private TextView txtFileName;
    private Uri selectedFileUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        prefManager = new PrefManager(this);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        imgThemeToggle = findViewById(R.id.imgThemeToggle);
        updateThemeIcon();

        imgThemeToggle.setOnClickListener(v -> {
            boolean isDark = prefManager.isDarkMode();
            prefManager.setDarkMode(!isDark);
            applyTheme(!isDark);
        });

        // Language Spinner
        Spinner spinnerLang = findViewById(R.id.spinnerLanguage);
        String[] languages = {"فارسی", "English"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, languages);
        spinnerLang.setAdapter(adapter);

        // File Attachment
        txtFileName = findViewById(R.id.txtFileName);
        findViewById(R.id.btnAttachFile).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        findViewById(R.id.btnSendToBale).setOnClickListener(v -> {
            sendToBale();
        });
    }

    private void updateThemeIcon() {
        if (prefManager.isDarkMode()) {
            imgThemeToggle.setImageResource(R.drawable.ic_moon);
        } else {
            imgThemeToggle.setImageResource(R.drawable.ic_sun);
        }
    }

    private void applyTheme(boolean isDark) {
        if (isDark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        recreate();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedFileUri = data.getData();
            txtFileName.setText("فایل انتخاب شد");
        }
    }

    private void sendToBale() {
        String description = ((android.widget.EditText) findViewById(R.id.etIssueDescription)).getText().toString();
        if (description.isEmpty()) {
            Toast.makeText(this, "لطفاً توضیحات را وارد کنید", Toast.LENGTH_SHORT).show();
            return;
        }

        String botToken = "933675706:G9c1BnT1WORj91x__fE_1oKudeJbdI-X39o";
        String chatId = "2099254782";
        
        // دریافت اطلاعات کامل خیاط به صورت خودکار
        String tailorName = prefManager.getTailorName();
        String tailorGender = prefManager.getTailorGender();
        int tailorAge = prefManager.getTailorAge();

        String message = "📌 گزارش جدید از اپلیکیشن خیاطیار\n\n" + 
                         "👤 نام خیاط: " + tailorName + "\n" +
                         "🚻 جنسیت: " + tailorGender + "\n" +
                         "🎂 سن: " + tailorAge + "\n" +
                         "📝 متن گزارش: " + description;

        if (selectedFileUri != null) {
            message += "\n\n📎 (توجه: کاربر یک تصویر هم پیوست کرده است - در نسخه فعلی فقط متن ارسال می‌شود)";
        }

        String finalMessage = message;
        new Thread(() -> {
            try {
                String urlString = "https://tapi.bale.ai/bot" + botToken + "/sendMessage?chat_id=" + chatId + "&text=" + java.net.URLEncoder.encode(finalMessage, "UTF-8");
                java.net.URL url = new java.net.URL(urlString);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                int responseCode = conn.getResponseCode();
                
                runOnUiThread(() -> {
                    if (responseCode == 200) {
                        Toast.makeText(this, "گزارش شما با موفقیت به پشتیبانی ارسال شد", Toast.LENGTH_SHORT).show();
                        ((android.widget.EditText) findViewById(R.id.etIssueDescription)).setText("");
                        selectedFileUri = null;
                        txtFileName.setText("فایلی انتخاب نشده");
                    } else {
                        Toast.makeText(this, "خطا در برقراری ارتباط با سرور", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "اتصال اینترنت خود را بررسی کنید", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
