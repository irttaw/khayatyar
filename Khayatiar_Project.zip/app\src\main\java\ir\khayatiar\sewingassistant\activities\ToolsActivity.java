package ir.khayatiar.sewingassistant.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import ir.khayatiar.sewingassistant.R;
import java.util.Locale;

public class ToolsActivity extends AppCompatActivity {
    private EditText etValue;
    private TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tools);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        etValue = findViewById(R.id.etConvertValue);
        txtResult = findViewById(R.id.txtConvertResult);
        Button btnCmToInch = findViewById(R.id.btnCmToInch);
        Button btnInchToCm = findViewById(R.id.btnInchToCm);

        btnCmToInch.setOnClickListener(v -> convert(true));
        btnInchToCm.setOnClickListener(v -> convert(false));
    }

    private void convert(boolean cmToInch) {
        String input = etValue.getText().toString();
        if (input.isEmpty()) return;
        
        double val = Double.parseDouble(input);
        double result;
        if (cmToInch) {
            result = val / 2.54;
            txtResult.setText(String.format(Locale.US, "%.2f اینچ", result));
        } else {
            result = val * 2.54;
            txtResult.setText(String.format(Locale.US, "%.2f سانتی‌متر", result));
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
