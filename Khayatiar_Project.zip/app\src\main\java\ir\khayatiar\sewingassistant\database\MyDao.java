package ir.khayatiar.sewingassistant.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface MyDao {
    // Customers
    @Insert
    long insertCustomer(Customer customer);
    @Update
    void updateCustomer(Customer customer);
    @Delete
    void deleteCustomer(Customer customer);
    @Query("SELECT * FROM customers ORDER BY name ASC")
    LiveData<List<Customer>> getAllCustomers();
    @Query("SELECT * FROM customers WHERE id = :id")
    Customer getCustomerById(int id);

    // Orders
    @Insert
    long insertOrder(Order order);
    @Query("SELECT * FROM orders ORDER BY id DESC")
    LiveData<List<Order>> getAllOrders();
    @Query("SELECT COUNT(*) FROM orders WHERE status = 'در حال دوخت'")
    int getActiveOrdersCount();

    // Fabrics
    @Insert
    void insertFabric(Fabric fabric);
    @Query("SELECT * FROM fabrics")
    List<Fabric> getAllFabrics();
    @Update
    void updateFabric(Fabric fabric);

    // Accessories
    @Insert
    void insertAccessory(Accessory accessory);
    @Query("SELECT * FROM accessories")
    List<Accessory> getAllAccessories();

    // Finance
    @Insert
    void insertTransaction(Transaction transaction);
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    LiveData<List<Transaction>> getAllTransactions();
    
    @Insert
    void insertCheck(Check check);
    @Query("SELECT * FROM checks ORDER BY dueDate ASC")
    LiveData<List<Check>> getAllChecks();

    // Images & Voice
    @Insert
    void insertOrderImage(OrderImage image);
    @Query("SELECT * FROM order_images WHERE orderId = :orderId")
    List<OrderImage> getImagesByOrder(int orderId);

    @Insert
    void insertPatternImage(PatternImage image);
    @Query("SELECT * FROM pattern_images WHERE customerId = :customerId")
    List<PatternImage> getPatternsByCustomer(int customerId);

    @Insert
    void insertVoiceNote(VoiceNote note);
    @Query("SELECT * FROM voice_notes WHERE orderId = :orderId")
    List<VoiceNote> getVoiceNotesByOrder(int orderId);
}
