package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "fabrics")
public class Fabric {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public String type;
    public double width;
    public double pricePerMeter;
    public double stock;
}
