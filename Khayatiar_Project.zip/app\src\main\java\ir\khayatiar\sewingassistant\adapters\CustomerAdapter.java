package ir.khayatiar.sewingassistant.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.database.Customer;
import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.ViewHolder> {

    private List<Customer> customers;

    public CustomerAdapter(List<Customer> customers) {
        this.customers = customers;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_customer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Customer customer = customers.get(position);
        holder.txtName.setText(customer.name);
        holder.txtPhone.setText(customer.phone);
        
        if ("آقا".equals(customer.gender)) {
            holder.imgGender.setImageResource(R.drawable.ic_male);
        } else {
            holder.imgGender.setImageResource(R.drawable.ic_female);
        }
    }

    @Override
    public int getItemCount() {
        return customers != null ? customers.size() : 0;
    }

    public void updateData(List<Customer> newCustomers) {
        this.customers = newCustomers;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtName, txtPhone;
        android.widget.ImageView imgGender;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtPhone = itemView.findViewById(R.id.txtPhone);
            imgGender = itemView.findViewById(R.id.imgGender);
        }
    }
}
