package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "checks")
public class Check {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String customerName;
    public double amount;
    public String dueDate;
    public String bankName;
    public boolean isCashed;
}
