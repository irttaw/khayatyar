package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "accessories")
public class Accessory {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public double stock;
    public double unitPrice;
}
