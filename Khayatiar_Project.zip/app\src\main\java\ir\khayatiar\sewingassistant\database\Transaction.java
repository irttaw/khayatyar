package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "transactions")
public class Transaction {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int orderId; // اگر مربوط به سفارش باشد
    public String title;
    public double amount;
    public String type; // "درآمد" یا "هزینه"
    public String date;
}
