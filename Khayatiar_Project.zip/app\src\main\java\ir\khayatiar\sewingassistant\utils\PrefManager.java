package ir.khayatiar.sewingassistant.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    private static final String PREF_NAME = "khayatiar_prefs";
    private static final String KEY_TAILOR_NAME = "tailor_name";
    private static final String KEY_TAILOR_GENDER = "tailor_gender";
    private static final String KEY_TAILOR_AGE = "tailor_age";
    private static final String KEY_IS_FIRST_TIME = "is_first_time";
    private static final String KEY_SMS_ENABLED = "sms_enabled";
    private static final String KEY_REMINDER_ENABLED = "reminder_enabled";
    private static final String KEY_DARK_MODE = "dark_mode";

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    public PrefManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void setTailorInfo(String name, String gender, int age) {
        editor.putString(KEY_TAILOR_NAME, name);
        editor.putString(KEY_TAILOR_GENDER, gender);
        editor.putInt(KEY_TAILOR_AGE, age);
        editor.putBoolean(KEY_IS_FIRST_TIME, false);
        editor.apply();
    }

    public String getTailorName() {
        return pref.getString(KEY_TAILOR_NAME, "خیاط");
    }

    public String getTailorGender() {
        return pref.getString(KEY_TAILOR_GENDER, "خانم");
    }

    public int getTailorAge() {
        return pref.getInt(KEY_TAILOR_AGE, 30);
    }

    public boolean isFirstTime() {
        return pref.getBoolean(KEY_IS_FIRST_TIME, true);
    }

    public void setSmsEnabled(boolean enabled) {
        editor.putBoolean(KEY_SMS_ENABLED, enabled);
        editor.apply();
    }

    public boolean isSmsEnabled() {
        return pref.getBoolean(KEY_SMS_ENABLED, false);
    }

    public void setReminderEnabled(boolean enabled) {
        editor.putBoolean(KEY_REMINDER_ENABLED, enabled);
        editor.apply();
    }

    public boolean isReminderEnabled() {
        return pref.getBoolean(KEY_REMINDER_ENABLED, true);
    }

    public void setDarkMode(boolean enabled) {
        editor.putBoolean(KEY_DARK_MODE, enabled);
        editor.apply();
    }

    public boolean isDarkMode() {
        return pref.getBoolean(KEY_DARK_MODE, false);
    }
}
