package ir.khayatiar.sewingassistant.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.database.AppDatabase;
import ir.khayatiar.sewingassistant.database.MyDao;

public class KanbanActivity extends AppCompatActivity {
    private MyDao myDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanban);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myDao = AppDatabase.getInstance(this).myDao();
        
        setupRecyclerView(findViewById(R.id.rvWaiting));
        setupRecyclerView(findViewById(R.id.rvSewing));
        setupRecyclerView(findViewById(R.id.rvReady));
    }

    private void setupRecyclerView(RecyclerView rv) {
        rv.setLayoutManager(new LinearLayoutManager(this));
        // اینجا آداپتور مخصوص برای نمایش کارت‌های کوچک سفارش وصل می‌شود
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
