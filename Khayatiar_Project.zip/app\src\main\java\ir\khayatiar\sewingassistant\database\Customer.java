package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "customers")
public class Customer {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public String phone;
    public String gender; // "آقا" یا "خانم"
    
    // اندازه‌ها (سانتی‌متر)
    public double chest;   // دور سینه
    public double waist;   // دور کمر
    public double hips;    // دور باسن
    public double height;  // قد
    public double sleeve;  // قد آستین
    public double arm;     // دور بازو
}
