package ir.khayatiar.sewingassistant.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Customer.class, Order.class, Fabric.class, Accessory.class, Transaction.class, Check.class, OrderImage.class, PatternImage.class, VoiceNote.class}, version = 4)
public abstract class AppDatabase extends RoomDatabase {
    public abstract MyDao myDao();
    private static AppDatabase instance;

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    AppDatabase.class, "khayatiar_db")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }
}
