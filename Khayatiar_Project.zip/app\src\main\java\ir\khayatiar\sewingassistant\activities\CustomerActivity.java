package ir.khayatiar.sewingassistant.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.adapters.CustomerAdapter;
import ir.khayatiar.sewingassistant.database.AppDatabase;
import ir.khayatiar.sewingassistant.database.Customer;
import java.util.ArrayList;
import java.util.List;

public class CustomerActivity extends AppCompatActivity {

    private CustomerAdapter adapter;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customers);

        db = AppDatabase.getInstance(this);
        RecyclerView recyclerView = findViewById(R.id.rvCustomers);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        adapter = new CustomerAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        db.myDao().getAllCustomers().observe(this, new Observer<List<Customer>>() {
            @Override
            public void onChanged(List<Customer> customers) {
                adapter.updateData(customers);
            }
        });

        findViewById(R.id.fabAddCustomer).setOnClickListener(v -> {
            showAddCustomerDialog();
        });
    }

    private void showAddCustomerDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        android.view.View view = getLayoutInflater().inflate(R.layout.dialog_add_customer, null);
        builder.setView(view);
        android.app.AlertDialog dialog = builder.create();

        android.widget.EditText etName = view.findViewById(R.id.etName);
        android.widget.EditText etPhone = view.findViewById(R.id.etPhone);
        android.widget.RadioGroup rgGender = view.findViewById(R.id.rgGender);
        android.widget.Button btnSave = view.findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String phone = etPhone.getText().toString();
            String gender = rgGender.getCheckedRadioButtonId() == R.id.rbMale ? "آقا" : "خانم";
            
            if (!name.isEmpty()) {
                Customer customer = new Customer();
                customer.name = name;
                customer.phone = phone;
                customer.gender = gender;
                new Thread(() -> {
                    db.myDao().insertCustomer(customer);
                    runOnUiThread(dialog::dismiss);
                }).start();
            }
        });

        dialog.show();
    }
}
