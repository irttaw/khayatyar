package ir.khayatiar.sewingassistant.activities;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.database.AppDatabase;
import ir.khayatiar.sewingassistant.database.MyDao;

public class FinanceActivity extends AppCompatActivity {
    private MyDao myDao;
    private TextView txtTotalBalance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finance);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        myDao = AppDatabase.getInstance(this).myDao();
        txtTotalBalance = findViewById(R.id.txtTotalBalance);

        loadFinancialData();
    }

    private void loadFinancialData() {
        // در نسخه های بعدی محاسبات پیچیده تر اضافه می شود
        txtTotalBalance.setText("۰ تومان");
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
