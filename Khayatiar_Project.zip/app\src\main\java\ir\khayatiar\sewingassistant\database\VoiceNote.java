package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "voice_notes")
public class VoiceNote {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int orderId;
    public String filePath;
    public String date;
}
