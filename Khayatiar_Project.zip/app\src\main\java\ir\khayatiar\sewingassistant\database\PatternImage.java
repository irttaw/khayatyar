package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "pattern_images")
public class PatternImage {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int customerId;
    public String imagePath;
    public String title;
}
