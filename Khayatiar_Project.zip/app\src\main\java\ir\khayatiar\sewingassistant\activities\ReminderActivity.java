package ir.khayatiar.sewingassistant.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.database.AppDatabase;
import ir.khayatiar.sewingassistant.database.MyDao;

public class ReminderActivity extends AppCompatActivity {
    private MyDao myDao;
    private Spinner spinnerCustomers, spinnerOrders;
    private TextView txtSelectedDateTime;
    private RadioGroup rgAlarmType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        myDao = AppDatabase.getInstance(this).myDao();
        spinnerCustomers = findViewById(R.id.spinnerCustomers);
        spinnerOrders = findViewById(R.id.spinnerOrders);
        txtSelectedDateTime = findViewById(R.id.txtSelectedDateTime);
        rgAlarmType = findViewById(R.id.rgAlarmType);
        
        Button btnSelectDateTime = findViewById(R.id.btnSelectDateTime);
        Button btnSetReminder = findViewById(R.id.btnSetReminder);

        btnSelectDateTime.setOnClickListener(v -> {
            showDateTimePicker();
        });

        btnSetReminder.setOnClickListener(v -> {
            if (txtSelectedDateTime.getText().toString().contains("هنوز")) {
                Toast.makeText(this, "لطفاً زمان را انتخاب کنید", Toast.LENGTH_SHORT).show();
                return;
            }
            String type = rgAlarmType.getCheckedRadioButtonId() == R.id.rbAlarm ? "هشدار صوتی" : "نوتیفیکیشن";
            Toast.makeText(this, "یادآور برای این سفارش با موفقیت ثبت شد (" + type + ")", Toast.LENGTH_LONG).show();
            finish();
        });
        
        loadCustomers();
    }

    private void showDateTimePicker() {
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        new android.app.DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            new android.app.TimePickerDialog(this, (view1, hourOfDay, minute) -> {
                String dateTime = year + "/" + (month + 1) + "/" + dayOfMonth + " - " + hourOfDay + ":" + minute;
                txtSelectedDateTime.setText(dateTime);
            }, calendar.get(java.util.Calendar.HOUR_OF_DAY), calendar.get(java.util.Calendar.MINUTE), true).show();
        }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH)).show();
    }

    private void loadCustomers() {
        // TODO: Fill spinner from database
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
