package ir.khayatiar.sewingassistant.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "orders")
public class Order {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int customerId;
    public String clothType;
    public String model;
    public int count;
    
    // پارچه
    public int fabricId; // 0 if manual
    public double fabricMetrage;
    public double fabricPrice;
    public String fabricPattern; // ساده، چهارخانه و...
    
    // هزینه‌ها
    public double accessoriesTotal;
    public double wage;
    public double extraCost;
    public double discount;
    public boolean isDiscountPercent;
    public double totalPrice;
    
    // زمان و وضعیت
    public String orderDate;
    public String deliveryDate;
    public String status; // در انتظار برش، در حال دوخت و...
    public String notes;
    
    // فیلدهای جدید
    public String imagePath; // آدرس تصویر لباس
    public boolean isReminderEnabled; // فعال بودن یادآور برای این سفارش
}
