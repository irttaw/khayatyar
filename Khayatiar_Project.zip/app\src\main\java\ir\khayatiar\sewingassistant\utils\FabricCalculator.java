package ir.khayatiar.sewingassistant.utils;

public class FabricCalculator {
    public static double calculate(String type, double height, double sleeve, double fabricWidth) {
        double needed = 0;
        switch (type) {
            case "شلوار":
                needed = height + 20; // قد شلوار + زاپاس
                break;
            case "پیراهن":
                needed = height + sleeve + 40;
                break;
            case "مانتو":
                needed = (height * 2) + 30;
                break;
            default:
                needed = height + 50;
        }
        return needed / 100.0; // تبدیل به متر
    }
}
