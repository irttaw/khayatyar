package ir.khayatiar.sewingassistant.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import ir.khayatiar.sewingassistant.MainActivity;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.utils.PrefManager;

public class WelcomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        PrefManager prefManager = new PrefManager(this);
        if (!prefManager.isFirstTime()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_welcome);

        EditText etName = findViewById(R.id.etTailorName);
        RadioGroup rgGender = findViewById(R.id.rgTailorGender);
        SeekBar sbAge = findViewById(R.id.sbAge);
        TextView txtAgeValue = findViewById(R.id.txtAgeValue);
        Button btnStart = findViewById(R.id.btnStart);

        sbAge.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                txtAgeValue.setText(" " + (progress + 1));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnStart.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String gender = rgGender.getCheckedRadioButtonId() == R.id.rbTailorMale ? "آقا" : "خانم";
            int age = sbAge.getProgress() + 1;

            if (!name.isEmpty()) {
                prefManager.setTailorInfo(name, gender, age);
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                etName.setError("لطفاً نام را وارد کنید");
            }
        });
    }
}
