package ir.khayatiar.sewingassistant;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import ir.khayatiar.sewingassistant.database.AppDatabase;
import ir.khayatiar.sewingassistant.database.MyDao;
import ir.khayatiar.sewingassistant.utils.PrefManager;

public class MainActivity extends AppCompatActivity {
    
    private MyDao myDao;
    private TextView txtStatus, txtWelcome;
    private DrawerLayout drawerLayout;
    private PrefManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        prefManager = new PrefManager(this);
        if (prefManager.isDarkMode()) {
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO);
        }
        
        setContentView(R.layout.activity_main);
        myDao = AppDatabase.getInstance(this).myDao();

        // Toolbar & Drawer Setup
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        
        // Handle Hamburger click to go to settings
        toolbar.setNavigationOnClickListener(v -> {
            startActivity(new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.SettingsActivity.class));
        });

        // Update Header
        View headerView = navigationView.getHeaderView(0);
        TextView txtHeaderName = headerView.findViewById(R.id.txtHeaderTailorName);
        txtHeaderName.setText(prefManager.getTailorName());

        txtWelcome = findViewById(R.id.txtWelcome);
        txtStatus = findViewById(R.id.txtStatus);
        
        txtWelcome.setText("خوش آمدید، " + prefManager.getTailorName());

        // Sidebar Menu Clicks
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_settings) {
                startActivity(new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.SettingsActivity.class));
            } else if (id == R.id.nav_profile) {
                // Open Profile edit
            }
            drawerLayout.closeDrawers();
            return true;
        });

        findViewById(R.id.btnCustomers).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.CustomerActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btnOrders).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.KanbanActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btnTools).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.ToolsActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btnFinance).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.FinanceActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btnReminder).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.ReminderActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.fabAddOrder).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(this, ir.khayatiar.sewingassistant.activities.AddOrderActivity.class);
            startActivity(intent);
        });

        updateStats();
    }

    private void updateStats() {
        new Thread(() -> {
            int count = myDao.getActiveOrdersCount();
            runOnUiThread(() -> txtStatus.setText("سفارشات فعال: " + count));
        }).start();
    }
}
