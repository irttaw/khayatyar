package ir.khayatiar.sewingassistant.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import ir.khayatiar.sewingassistant.R;
import ir.khayatiar.sewingassistant.database.AppDatabase;
import ir.khayatiar.sewingassistant.database.Customer;
import ir.khayatiar.sewingassistant.database.MyDao;
import ir.khayatiar.sewingassistant.database.Order;
import java.util.ArrayList;
import java.util.List;

public class AddOrderActivity extends AppCompatActivity {
    private MyDao myDao;
    private Spinner spinnerCustomers;
    private AutoCompleteTextView etClothType;
    private LinearLayout containerAccessories;
    private List<Customer> customerList;
    private EditText etM1, etM2, etM3, etM4, etM5, etM6;
    private android.net.Uri selectedImageUri;
    private ImageView imgPreview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_order);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        myDao = AppDatabase.getInstance(this).myDao();
        initViews();
        loadCustomers();

        findViewById(R.id.btnLoadMeasurements).setOnClickListener(v -> loadStoredMeasurements());
        findViewById(R.id.btnAddAccessory).setOnClickListener(v -> addAccessoryField());
        findViewById(R.id.btnSaveFinal).setOnClickListener(v -> saveOrder());
        
        imgPreview = findViewById(R.id.imgOrderPreview);
        findViewById(R.id.btnPickImage).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 100);
        });
    }

    private void initViews() {
        spinnerCustomers = findViewById(R.id.spinnerCustomers);
        etClothType = findViewById(R.id.etClothType);
        containerAccessories = findViewById(R.id.containerAccessories);
        etM1 = findViewById(R.id.etM1);
        etM2 = findViewById(R.id.etM2);
        etM3 = findViewById(R.id.etM3);
        etM4 = findViewById(R.id.etM4);
        etM5 = findViewById(R.id.etM5);
        etM6 = findViewById(R.id.etM6);
        
        String[] types = {"مانتو", "شلوار", "پیراهن", "کت", "دامن", "جلیقه", "بلوز"};
        etClothType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, types));
    }

    private void loadCustomers() {
        myDao.getAllCustomers().observe(this, customers -> {
            customerList = customers;
            List<String> names = new ArrayList<>();
            for (Customer c : customers) names.add(c.name);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerCustomers.setAdapter(adapter);
        });
    }

    private void loadStoredMeasurements() {
        if (customerList == null || customerList.isEmpty()) return;
        Customer c = customerList.get(spinnerCustomers.getSelectedItemPosition());
        etM1.setText(String.valueOf(c.height));
        etM2.setText(String.valueOf(c.chest));
        etM3.setText(String.valueOf(c.waist));
        etM4.setText(String.valueOf(c.hips));
        etM5.setText(String.valueOf(c.sleeve));
        etM6.setText(String.valueOf(c.arm));
        Toast.makeText(this, "اندازه‌های مشتری بارگیری شد", Toast.LENGTH_SHORT).show();
    }

    private void addAccessoryField() {
        View view = LayoutInflater.from(this).inflate(R.layout.item_accessory_input, null);
        view.findViewById(R.id.btnRemoveAcc).setOnClickListener(v -> containerAccessories.removeView(view));
        containerAccessories.addView(view);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            imgPreview.setImageURI(selectedImageUri);
        }
    }

    private void saveOrder() {
        if (customerList == null || customerList.isEmpty()) {
            Toast.makeText(this, "ابتدا مشتری ثبت کنید", Toast.LENGTH_SHORT).show();
            return;
        }

        Order order = new Order();
        order.customerId = customerList.get(spinnerCustomers.getSelectedItemPosition()).id;
        order.clothType = etClothType.getText().toString();
        order.status = "منتظر برش";
        if (selectedImageUri != null) {
            order.imagePath = selectedImageUri.toString();
        }
        
        new Thread(() -> {
            myDao.insertOrder(order);
            runOnUiThread(() -> {
                Toast.makeText(this, "سفارش با موفقیت ثبت و به میز کار اضافه شد", Toast.LENGTH_SHORT).show();
                finish();
            });
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
